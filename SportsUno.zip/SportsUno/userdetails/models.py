from django.db import models

class UserDetails(models.Model):
    id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=50, blank=True, )
    last_name = models.CharField(max_length=50, blank=True, null=True)
    contact_number = models.CharField(max_length=200, blank=True, null=True)
    email_id = models.CharField(max_length=55)
    dob = models.CharField(max_length=200, blank=True, null=True)