from django.shortcuts import render


from django.template import RequestContext
from django.shortcuts import render
from django.http import HttpResponse
from django.template import RequestContext
from .models import *
from django.template import Template

def home(request):
    # template = loader.get_template('home.html')
    if request.method == 'POST':
        first_name=   request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        contact_number = request.POST.get('contact_number')
        email_id = request.POST.get('email_id')
        dob = request.POST.get('dob')
        userdetails = UserDetails.objects.create(first_name=first_name,last_name=last_name,contact_number=contact_number,
                                         email_id=email_id,dob=dob)
        #mgs = ''
        if userdetails:
        	print("helloooooooo")
        	mgs = "record add sucess"
        	return render(request, 'test.html',{'mgs':mgs})
    return render(request, 'test.html',)


def Listview(request):
    # template = loader.get_template('home.html')
    listall = UserDetails.objects.all()      
    return render(request, 'exportdata.html',{'listall':listall},)
                